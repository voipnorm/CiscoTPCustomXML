const xapi = require('xapi');

function disconnect(){
  xapi.command("call disconnect");
}

disconnect();