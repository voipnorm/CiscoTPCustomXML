/** Show a message on the video screen */
const xapi = require('xapi');

function alert(title, text = '', duration = 5) {
  xapi.command('UserInterface Message Alert Display', {
    Title: title,
    Text: text,
    Duration: duration,
  });
}

alert('Good morning', 'Early bird catch the worms');
